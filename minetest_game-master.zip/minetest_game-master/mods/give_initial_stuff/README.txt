Minetest Game mod: give_initial_stuff
=====================================
See license.txt for license information.

Authors of source code
----------------------
Perttu Ahola (celeron55) <celeron55@gmail.com> (MIT)
Various Minetest developers and contributors (MIT)
